Sine of the Chimes
https://github.com/tom-seddon/256_bytes/

By Tom Seddon of the Bitshifters Collective.
Visit us at: https://bitshifters.github.io/

Tiny (256 byte) intro for the BBC Master 128.
Released at Nova, June 2023

We took some artistic licence when choosing the name. There aren't
actually any sines here.

(Loops indefinitely. The video shows you everything there is to
experience.)
